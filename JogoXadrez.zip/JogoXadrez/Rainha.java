
/**
 * Escreva a descrição da classe Rainha aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Rainha extends Peca
{
    private Casa casa;
    private int tipo;

    /**
     * Construtor para objetos da classe Torre
     */
    public Rainha(Casa casa, int tipo)
    {
        super(casa, tipo);
        
    }
}
