
/**
 * Escreva a descrição da classe Torre aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Torre extends Peca
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private Casa casa;
    private int tipo;

    /**
     * Construtor para objetos da classe Torre
     */
    public Torre(Casa casa, int tipo)
    {
        super(casa, tipo);
        
    }

    
}
