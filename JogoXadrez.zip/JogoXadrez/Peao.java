
/**
 * Escreva a descrição da classe Peao aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Peao extends Peca
{
    //private Casa casa;
    private int direcao;
    private boolean primeiroMovimento;
    /**
     * Construtor para objetos da classe Torre
     */
    public Peao(Casa casa, int tipo)
    {
        super(casa, tipo);
        this.casa = casa;
        if(tipo == PEAO_BRANCO) {
            direcao = 1;
        }
        else if(tipo == PEAO_PRETO){
            direcao = -1;
        }
        primeiroMovimento = true;
    }
    
    public void primeiroMovimento(Casa destino){
        if(primeiroMovimento && !destino.possuiPeca()){
            
            
            if(casa.getX() == destino.getX() && (casa.getY()+2 == destino.getY() || casa.getY()+direcao == destino.getY())){
                super.mover(destino);   
                primeiroMovimento = false;
            }
        }
        else if(!primeiroMovimento && !destino.possuiPeca()){
            if(casa.getX() == destino.getX() && (casa.getY()+1 == destino.getY())){
                super.mover(destino);  
                
            }
        }
    }
    
    public void capturar(Casa destino){
        if(destino.possuiPeca() && (getTipoGeral() != destino.getPeca().getTipoGeral())){
            if((casa.getX()+1 == destino.getX() || casa.getX()-1 == destino.getX()) && casa.getY()+1 == destino.getY()){
                    super.capturar(destino);   
            }
        }
    }
    
    
    
}
