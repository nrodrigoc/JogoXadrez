
/**
 * Escreva a descrição da classe Cavalo aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Cavalo extends Peca
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private Casa casa;
    private int tipo;

    /**
     * Construtor para objetos da classe Torre
     */
    public Cavalo(Casa casa, int tipo)
    {
        super(casa, tipo);
        
    }
}
