
/**
 * Escreva a descrição da classe Rei aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Rei extends Peca
{
    private Casa casa;
    private int tipo;

    /**
     * Construtor para objetos da classe Torre
     */
    public Rei(Casa casa, int tipo)
    {
        super(casa, tipo);
        
    }
}
